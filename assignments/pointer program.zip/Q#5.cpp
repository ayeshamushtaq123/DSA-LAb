#include <iostream>

struct Point {
    int x, y;
};

int main() {
    Point p = {3, 4};
    Point *ptr = &p;
    std::cout << "x: " << ptr->x << ", y: " << ptr->y << std::endl;
    return 0;
}

