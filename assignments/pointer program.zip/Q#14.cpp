#include <iostream>

int add(int a, int b) {
    return a + b;
}

int main() {
    int (*ptr)(int, int) = &add;
    std::cout << "Result: " << (*ptr)(5, 7) << std::endl;
    return 0;
}

