#include <iostream>

int main() {
    int num = 42;
    int *ptr1 = &num;
    int **ptr2 = &ptr1;
    std::cout << "Value of num: " << **ptr2 << std::endl;
    return 0;
}

