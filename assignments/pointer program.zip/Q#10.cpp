#include <cstring>

int main() {
    const char *str = "Hello, World!";
    std::cout << "String: " << str << std::endl;
    return 0;
}

