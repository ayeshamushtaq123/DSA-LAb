#include <iostream>

int main() {
    const int num = 10;
    const int *ptr = &num;
    // *ptr = 20; // Error: Cannot modify constant data through ptr
    std::cout << "Value of num: " << *ptr << std::endl;
    return 0;
}

