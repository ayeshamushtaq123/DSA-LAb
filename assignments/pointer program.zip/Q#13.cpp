#include <iostream>

int main() {
    const char str[] = "Hello, World!";
    const char *ptr = str;
    std::cout << "String: " << ptr << std::endl;
    return 0;
}

