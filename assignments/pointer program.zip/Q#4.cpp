#include <iostream>

void sayHello() {
    std::cout << "Hello, World!" << std::endl;
}

int main() {
    void (*func_ptr)() = &sayHello;
    (*func_ptr)(); // Call the function using a pointer
    return 0;
}

