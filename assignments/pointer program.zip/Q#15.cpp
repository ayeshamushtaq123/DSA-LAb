#include <iostream>

class MyClass {
public:
    int value;

    void setValue(int val) {
        value = val;
    }
};

int main() {
    MyClass obj;
    MyClass *ptr = &obj;
    ptr->setValue(42);
    std::cout << "Value: " << obj.value << std::endl;
    return 0;
}

