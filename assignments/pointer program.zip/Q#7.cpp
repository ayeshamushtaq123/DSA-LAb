#include <iostream>

int main() {
    int *ptr = new int;
    *ptr = 42;
    std::cout << "Value at ptr: " << *ptr << std::endl;
    delete ptr; // Deallocate memory
    return 0;
}

