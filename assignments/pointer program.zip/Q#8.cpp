#include <iostream>

int main() {
    int *arr = new int[5];
    for (int i = 0; i < 5; ++i) {
        arr[i] = i * 2;
    }
    for (int i = 0; i < 5; ++i) {
        std::cout << "Element " << i << ": " << arr[i] << std::endl;
    }
    delete[] arr; // Deallocate memory
    return 0;
}

