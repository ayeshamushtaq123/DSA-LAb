#include <iostream>

int main() {
    int num = 42;
    int *const ptr = &num;
    *ptr = 100; // OK
    // ptr = nullptr; // Error: Cannot change the pointer
    std::cout << "Value of num: " << *ptr << std::endl;
    return 0;
}

