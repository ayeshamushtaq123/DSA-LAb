#include <iostream>

int main() {
    int arr[] = {1, 2, 3, 4, 5};
    int *ptr = arr;
    std::cout << "Second element: " << *(ptr + 1) << std::endl;
    return 0;
}

