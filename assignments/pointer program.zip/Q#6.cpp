#include <iostream>

void square(int *ptr) {
    *ptr = (*ptr) * (*ptr);
}

int main() {
    int num = 5;
    square(&num);
    std::cout << "Squared value: " << num << std::endl;
    return 0;
}

