#include <iostream>

int main() {
    int num = 10;
    int *ptr = &num;
    std::cout << "Value of num: " << num << std::endl;
    std::cout << "Value using pointer: " << *ptr << std::endl;
    return 0;
}

